//npm i express
//npm i EJS
//npm i nodemon (faz o sever rodar)
//importa o express
const express = require("express")
const { json } = require("express/lib/response")
const path = require("path")
const mysql = require('mysql2/promise')

//Ultiliza o express
const App = express()
//faz com que o servidor retorne o ejs e não seu servidor padrao
//shift alt seta para baixo duplica
App.set("view engine", "ejs")
App.set("views", path.join(__dirname, "mvc/views"))
App.use(express.static(path.join(__dirname, "public")))

//configuração que permite a transformação de forms em json
App.use(express.urlencoded({extended: true}))
App.use(express.json())


const connection = mysql.createPool({
    host: '127.0.0.1',
    user: 'root',
    database: 'login',
    password: ''
})

App.get('/statusbd', async (req, res) => {
    const [rows] = await connection.execute('select now()')

    res.json({
        msg:rows
    })
})

//End point
App.get("/", (req, res) =>{
    res.render("index", {
        erro: {
            usuario: "",
            senha: ""
        }
    }
    )
})

App.get('/dados_login', async (req, res) =>{
    const sql = 'select *from dados'
    const [rows] = await connection.execute(sql)

    res.json({
        dados: rows
    })
})


App.post("/login", async (req, res) => { // Alteração para 'async' porque precisamos usar 'await' para a consulta ao banco

    if (req.body.usuario === "" || req.body.senha === "") {
        res.render("index", {
            erro: {
                usuario: "Usuário incorreto!",
                senha: "Senha incorreta!"
            }
        });
    } else {
        const { usuario, senha } = req.body;

        const [rows] = await connection.execute(
            "SELECT * FROM dados WHERE usuario = ?", 
            [usuario]
        );

        
        if (rows.length === 0) {
            res.render("index", {
                erro: {
                    usuario: "Usuário não encontrado!",
                    senha: ""
                }
            });
        } else {
            
            const senhaBanco = rows[0].senha;

            
            if (senha === senhaBanco) {
                
                res.render("inicial");
            } else {

                res.render("index", {
                    erro: {
                        usuario: "",
                        senha: "Senha incorreta!"
                    }
                });
            }
        }
    }
});










































//Deixar disponivel para execução
App.listen(3000, () => console.log("Servidor online") )


 